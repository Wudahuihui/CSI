from django.shortcuts import render
from login.models import User
from django.shortcuts import HttpResponse
# Create your views here.

#显示注册界面
def regist_view(request):
    return render(request, "login/regist.html")

#处理注册功能
def user_regist(request):
    user_name = request.GET.get("user_name")
    password = request.GET.get("password")
    age = request.GET.get("age")
    if user_name and password and age:
        User.objects.create(user_name=user_name, password=password, age=age)
        return render(request,"login/login.html")
    return HttpResponse("注册失败！")
#    return render(request, "login/regist.html")