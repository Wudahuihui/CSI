from django.conf.urls import url
from django.urls import path,include
from.import views

from django.urls import path,include
from.import views
urlpatterns = [
    url('^$',views.regist_view),
    url('reg/',views.user_regist),
]