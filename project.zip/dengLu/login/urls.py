#from django.contrib import admin
#from django.urls import path
#from login import views

#coding=utf-8
from django.conf.urls import url
from django.urls import path,include


from.import views
urlpatterns = [
    url('^$',views.index_login_view),
    url('log/',views.login_view),
    path('regist/',include('regist.urls')),









#    url('reg/',views.userRegist)

    #访问注册界面 http://127.0.0.1:8000/regist/，会执行views中的regist方法，下一个相同的道理
#    path('regist/',views.regist),
#    path('login/',views.login),
#    path('log/',views.UserController.userLogin),
    #访问注册界面
    # http://127.0.0.1:8000/userRegist/，会执行views中Usercontrller的regist方法，下一个相同的道理
#    path('/userRegist/',views.UserController.userRegist),
#    path('/userLogin/',views.UserController.userLogin),
    # http://127.0.0.1:8000/userinfo/{这里需要一个整形参数，参数命名为id}/，这样的url会执行views中Usercontrller的userInfo方法，
#    path('userinfo/<int:id>',views.UserController.userInfo)
]
