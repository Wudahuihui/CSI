from django.shortcuts import render
from .models import User
from django.shortcuts import HttpResponse
# Create your views here.

#显示注册界面
def regist_view(request):
    return render(request, "login/regist.html")

    '''
    if request.method == 'POST':
        return render(request, "login/regist.html")
    else:
        user_name = request.POST.get("user_name")
        password = request.POST.get("password")
        age = request.POST.get("age")
        if user_name and password and age:
            user = User(user_name=user_name, password=password, age=age)
            user.save()
        return HttpResponse("注册成功")
    return HttpResponse("注册失败")
'''

'''
def regist_view(request):
    if request.method == 'POST':
        user_name = request.POST.get("user_name")
        password = request.POST.get("password")
        age = request.POST.get("age")
        User.objects.create(user_name=user_name, password=password, age=age)
    return render(request, "login/registp.html")
'''

#显示登录页面
def index_login_view(requst):
    return render(requst,"login/login.html")

#处理登录功能
def login_view(request):
    uname=request.POST.get("user_name")
    pwd=request.POST.get("password")
    user = User.objects.get(user_name=uname)
    if(user.password== pwd):
        return render(request,'userinfo.html',{'user':user})
    return HttpResponse("密码错误！")



"""
#下面三个都和用户有关，封装成UserController这个类，
class UserController:
    def userLogin(request):
        if request.method == 'POST':
            user_name = request.POST.get("user_name")
            password = request.POST.get("password")
            user = User.objects.get(user_name=user_name)
#            if user.password != password :
            if user_name=="mr" and password!="123456":
                return HttpResponse("密码错误")
        return render(request,"userinfo.html",{'user':user})

    def userRegist(request):
        if request.method == 'POST':
            user_name = request.POST.get("user_name")
            password = request.POST.get("password")
            age = request.POST.get("age")
            User.objects.create(user_name=user_name, password=password, age=age)
        return render(request, "login/login.html")

    def userInfo(request,id):
        user = User.objects.get(id=id)
        return render(request, "login/userinfo.html", {'user': user})
"""